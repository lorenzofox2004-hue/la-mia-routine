LA MIA ROUTINE — CHECKLIST OFFLINE PER IPHONE

CONTENUTO
- index.html: app
- manifest.webmanifest: impostazioni installazione
- sw.js: cache offline
- icon.svg e icon.png: icone

COME USARLA SU IPHONE
Per installarla come app e usare il service worker offline, i file devono essere pubblicati su un sito HTTPS.
Una possibilità gratuita è GitHub Pages:
1. Crea/accedi a un account GitHub.
2. Crea un nuovo repository pubblico, ad esempio "routine-checklist".
3. Carica tutti e quattro i file (README facoltativo) nella cartella principale.
4. In Settings > Pages, scegli "Deploy from a branch", branch "main", cartella "/ (root)" e salva.
5. Quando GitHub Pages mostra l'indirizzo del sito, aprilo con Safari su iPhone.
6. Apri la pagina una volta mentre sei online, attendi qualche secondo, poi Condividi > Aggiungi alla schermata Home.
7. Apri l'app dalla nuova icona. Prova la modalità aereo per verificare l'offline.

FUNZIONI
- Programma lunedì-venerdì preimpostato con gli orari forniti.
- Spunta un'attività per toglierla dalla lista "Da fare".
- "Mostra completate" permette di rivederle o deselezionarle.
- I progressi sono salvati localmente sul dispositivo.
- Al cambio della data, la checklist si resetta automaticamente.
- "Azzera questo giorno" permette di ripartire manualmente.

NOTA
I progressi sono salvati nel browser di questo dispositivo e non sincronizzati con altri dispositivi. Sabato e domenica non sono configurati perché non erano nell'elenco iniziale.
